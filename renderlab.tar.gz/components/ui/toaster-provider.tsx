"use client";

import { Toaster } from "@/components/ui/sonner";

export const ToasterProvider = () => {
  return <Toaster />;
};
