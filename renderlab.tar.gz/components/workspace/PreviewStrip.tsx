export function PreviewStrip() {
  return (
    <div className="flex items-center justify-center h-full text-muted-foreground">
      No preview yet.
    </div>
  );
}
