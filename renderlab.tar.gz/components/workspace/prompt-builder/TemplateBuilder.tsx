"use client";

import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { BookmarkSelector } from "./BookmarkSelector";
import { ModelSelector } from "./ModelSelector";

interface TemplateBuilderProps {
    // Model
    aiModel: string;
    onAiModelChange: (value: string) => void;

    // Details
    details: string;
    onDetailsChange: (value: string) => void;

    // Bookmark clicks - append to editable prompt
    onBookmarkClick: (text: string) => void;

    // Avoid Elements
    avoidElements: string;
    onAvoidElementsChange: (value: string) => void;
    onAvoidClick: (item: string) => void;

    // Uploaded Image
    uploadedImage?: string | null;

    // Actions
    onSaveTemplate: () => void;

    // State
    isGenerating: boolean;
}

export function TemplateBuilder({
    aiModel,
    onAiModelChange,
    details,
    onDetailsChange,
    onBookmarkClick,
    avoidElements,
    onAvoidElementsChange,
    onAvoidClick,
    uploadedImage,
    onSaveTemplate,
    isGenerating,
}: TemplateBuilderProps) {
    const handlePillSelect = (pillText: string) => {
        console.log('🟢 TemplateBuilder received:', pillText);

        // Call bookmark click handler to append to editable prompt
        onBookmarkClick(pillText);

        // Still update details for UI consistency
        let newDetails = "";

        if (!details || details.trim() === "") {
            // First selection
            newDetails = pillText;
        } else {
            // Subsequent selections - just append
            newDetails = `${details}, ${pillText}`;
        }

        console.log('🟢 New details after:', newDetails);
        onDetailsChange(newDetails);
    };

    return (
        <details
            className="rounded-xl p-4 border border-white/[0.06]"
            style={{
                background: '#1a1a1a',
                boxShadow: '0 8px 24px rgba(0, 0, 0, 0.5), 0 20px 56px rgba(0, 0, 0, 0.3)'
            }}
            open
        >
            <summary className="text-xs font-semibold text-gray-400 uppercase tracking-wide cursor-pointer list-none flex items-center justify-between mb-4">
                <span>Advanced Settings</span>
                <span className="text-lg">▼</span>
            </summary>
            <div className="space-y-4">
                {/* 1. AI MODEL - AT THE TOP */}
                <ModelSelector
                    value={aiModel}
                    onChange={onAiModelChange}
                    disabled={isGenerating}
                />

                {/* Divider */}
                <div className="h-px bg-neutral-200 dark:bg-neutral-700" />

                {/* 2. BOOKMARKS (4 categories + Elements to Avoid) */}
                <BookmarkSelector
                    onPillSelect={handlePillSelect}
                    onAvoidElementsChange={onAvoidElementsChange}
                    onAvoidClick={onAvoidClick}
                    disabled={isGenerating}
                />

                {/* Action Buttons */}
                <div className="flex w-full gap-3">
                    <Button
                        variant="outline"
                        className="flex-1 rounded-xl border-2 border-purple-500/30 bg-purple-500/5 text-purple-400 font-semibold hover:bg-purple-500/10 hover:border-purple-500/50 transition-all"
                        onClick={onSaveTemplate}
                    >
                        <Save className="w-4 h-4 mr-2" />
                        Save as Template
                    </Button>
                </div>
            </div>
        </details>
    );
}
