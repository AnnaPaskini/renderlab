import { createClient } from '@/lib/supabaseBrowser';
import { uploadImageToStorage } from '../../lib/utils/uploadToStorage';

/**
 * Uploads the reference image once and returns the uploaded URL.
 * @param referenceImage base64 string
 * @param userId string
 * @returns Promise<string | null>
 */
export async function uploadReferenceImageOnce(referenceImage: string, userId: string): Promise<string | null> {
    if (!referenceImage) return null;
    try {
        const supabase = createClient();
        // Use a unique filename
        const fileName = `reference_${Date.now()}.png`;
        const url = await uploadImageToStorage(supabase, referenceImage, userId, 'workspace', fileName);
        return url;
    } catch (error) {
        console.error('Failed to upload reference image once:', error);
        return null;
    }
}
