"use client";

export default function InpaintOverlay() {
  return null;
}
